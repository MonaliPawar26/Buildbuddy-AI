import { useState } from 'react'
import { useAuth } from '../hooks/useAuth'

export default function Settings() {
    const { profile, updateProfile } = useAuth()
    const [saving, setSaving] = useState(false)
    const [settings, setSettings] = useState({
        preferred_language: profile?.preferred_language || 'javascript',
        skill_level: profile?.skill_level || 'beginner',
    })
    const [toggles, setToggles] = useState({
        contextAware: true,
        showConfidence: true,
        darkMode: true,
        emailNotifications: false,
    })

    async function handleSave() {
        setSaving(true)
        await updateProfile(settings)
        setSaving(false)
    }

    function toggleSetting(key) {
        setToggles(prev => ({ ...prev, [key]: !prev[key] }))
    }

    return (
        <div className="page-container">
            <div className="page-header">
                <h1 className="page-title">Settings ⚙️</h1>
                <p className="page-subtitle">Customize your BuildBuddy experience</p>
            </div>

            {/* AI Preferences */}
            <div className="glass-card settings-section">
                <h3 className="settings-section-title">AI Preferences</h3>
                <div className="input-group">
                    <label className="input-label">Default Language</label>
                    <select
                        className="input-field"
                        value={settings.preferred_language}
                        onChange={e => setSettings({ ...settings, preferred_language: e.target.value })}
                    >
                        <option value="javascript">JavaScript</option>
                        <option value="python">Python</option>
                        <option value="typescript">TypeScript</option>
                        <option value="java">Java</option>
                        <option value="cpp">C++</option>
                        <option value="csharp">C#</option>
                        <option value="go">Go</option>
                        <option value="rust">Rust</option>
                        <option value="php">PHP</option>
                        <option value="swift">Swift</option>
                        <option value="kotlin">Kotlin</option>
                        <option value="html">HTML</option>
                        <option value="css">CSS</option>
                        <option value="sql">SQL</option>
                    </select>
                </div>
                <div className="input-group">
                    <label className="input-label">Explanation Depth</label>
                    <select
                        className="input-field"
                        value={settings.skill_level}
                        onChange={e => setSettings({ ...settings, skill_level: e.target.value })}
                    >
                        <option value="beginner">Beginner — Simple, step-by-step explanations</option>
                        <option value="intermediate">Intermediate — Standard technical detail</option>
                        <option value="advanced">Advanced — Concise, expert-level</option>
                    </select>
                </div>
                <button className="btn btn-primary" onClick={handleSave} disabled={saving}>
                    {saving ? 'Saving...' : 'Save Preferences'}
                </button>
            </div>

            {/* Feature Toggles */}
            <div className="glass-card settings-section">
                <h3 className="settings-section-title">Features</h3>
                <div className="settings-row">
                    <div>
                        <div style={{ fontWeight: 600, fontSize: 14 }}>Context-Aware Explanations</div>
                        <div style={{ fontSize: 13, color: 'var(--text-secondary)' }}>Use your coding history to personalize AI responses</div>
                    </div>
                    <div
                        className={`toggle ${toggles.contextAware ? 'active' : ''}`}
                        onClick={() => toggleSetting('contextAware')}
                    />
                </div>
                <div className="settings-row">
                    <div>
                        <div style={{ fontWeight: 600, fontSize: 14 }}>Show Confidence Score</div>
                        <div style={{ fontSize: 13, color: 'var(--text-secondary)' }}>Display your confidence score on the dashboard</div>
                    </div>
                    <div
                        className={`toggle ${toggles.showConfidence ? 'active' : ''}`}
                        onClick={() => toggleSetting('showConfidence')}
                    />
                </div>
                <div className="settings-row">
                    <div>
                        <div style={{ fontWeight: 600, fontSize: 14 }}>Dark Mode</div>
                        <div style={{ fontSize: 13, color: 'var(--text-secondary)' }}>Use dark theme (recommended for coding)</div>
                    </div>
                    <div
                        className={`toggle ${toggles.darkMode ? 'active' : ''}`}
                        onClick={() => toggleSetting('darkMode')}
                    />
                </div>
                <div className="settings-row">
                    <div>
                        <div style={{ fontWeight: 600, fontSize: 14 }}>Email Notifications</div>
                        <div style={{ fontSize: 13, color: 'var(--text-secondary)' }}>Weekly progress reports and tips</div>
                    </div>
                    <div
                        className={`toggle ${toggles.emailNotifications ? 'active' : ''}`}
                        onClick={() => toggleSetting('emailNotifications')}
                    />
                </div>
            </div>

            {/* Account */}
            <div className="glass-card settings-section">
                <h3 className="settings-section-title">Account</h3>
                <div className="settings-row">
                    <div>
                        <div style={{ fontWeight: 600, fontSize: 14 }}>Email</div>
                        <div style={{ fontSize: 13, color: 'var(--text-secondary)' }}>{profile?.id ? 'Connected' : 'Not set'}</div>
                    </div>
                    <span className="badge badge-green">Verified</span>
                </div>
                <div className="settings-row">
                    <div>
                        <div style={{ fontWeight: 600, fontSize: 14 }}>Delete Account</div>
                        <div style={{ fontSize: 13, color: 'var(--text-secondary)' }}>Permanently delete all your data</div>
                    </div>
                    <button className="btn btn-danger btn-sm">Delete</button>
                </div>
            </div>
        </div>
    )
}
