import { useState, useEffect } from 'react'
import { useAuth } from '../hooks/useAuth'
import { supabase } from '../lib/supabase'

export default function Profile() {
    const { user, profile, updateProfile } = useAuth()
    const [skillProfiles, setSkillProfiles] = useState([])
    const [editing, setEditing] = useState(false)
    const [form, setForm] = useState({ full_name: '', username: '', preferred_language: 'javascript', skill_level: 'beginner' })
    const [saving, setSaving] = useState(false)
    const [totalStats, setTotalStats] = useState({ sessions: 0, errors: 0 })

    useEffect(() => {
        if (profile) {
            setForm({
                full_name: profile.full_name || '',
                username: profile.username || '',
                preferred_language: profile.preferred_language || 'javascript',
                skill_level: profile.skill_level || 'beginner',
            })
        }
        if (user) loadSkillProfiles()
    }, [user, profile])

    async function loadSkillProfiles() {
        const { data } = await supabase
            .from('skill_profiles')
            .select('*')
            .eq('user_id', user.id)
        setSkillProfiles(data || [])
        const total = (data || []).reduce((acc, s) => ({
            sessions: acc.sessions + s.total_sessions,
            errors: acc.errors + s.errors_resolved,
        }), { sessions: 0, errors: 0 })
        setTotalStats(total)
    }

    async function handleSave() {
        setSaving(true)
        await updateProfile(form)
        setSaving(false)
        setEditing(false)
    }

    const initials = profile?.full_name
        ? profile.full_name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)
        : '?'

    return (
        <div className="page-container">
            <div className="page-header">
                <h1 className="page-title">Profile 👤</h1>
                <p className="page-subtitle">Your developer profile and skill overview</p>
            </div>

            {/* Profile Card */}
            <div className="glass-card" style={{ marginBottom: 24 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
                    <div className="sidebar-avatar" style={{ width: 72, height: 72, fontSize: 24 }}>
                        {initials}
                    </div>
                    <div style={{ flex: 1 }}>
                        {editing ? (
                            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                                    <div className="input-group" style={{ margin: 0 }}>
                                        <label className="input-label">Full Name</label>
                                        <input className="input-field" value={form.full_name} onChange={e => setForm({ ...form, full_name: e.target.value })} />
                                    </div>
                                    <div className="input-group" style={{ margin: 0 }}>
                                        <label className="input-label">Username</label>
                                        <input className="input-field" value={form.username} onChange={e => setForm({ ...form, username: e.target.value })} />
                                    </div>
                                </div>
                                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                                    <div className="input-group" style={{ margin: 0 }}>
                                        <label className="input-label">Preferred Language</label>
                                        <select className="input-field" value={form.preferred_language} onChange={e => setForm({ ...form, preferred_language: e.target.value })}>
                                            <option value="javascript">JavaScript</option>
                                            <option value="python">Python</option>
                                            <option value="typescript">TypeScript</option>
                                            <option value="java">Java</option>
                                            <option value="cpp">C++</option>
                                            <option value="csharp">C#</option>
                                            <option value="go">Go</option>
                                            <option value="rust">Rust</option>
                                            <option value="php">PHP</option>
                                            <option value="swift">Swift</option>
                                            <option value="kotlin">Kotlin</option>
                                            <option value="html">HTML</option>
                                            <option value="css">CSS</option>
                                            <option value="sql">SQL</option>
                                        </select>
                                    </div>
                                    <div className="input-group" style={{ margin: 0 }}>
                                        <label className="input-label">Skill Level</label>
                                        <select className="input-field" value={form.skill_level} onChange={e => setForm({ ...form, skill_level: e.target.value })}>
                                            <option value="beginner">Beginner</option>
                                            <option value="intermediate">Intermediate</option>
                                            <option value="advanced">Advanced</option>
                                        </select>
                                    </div>
                                </div>
                                <div style={{ display: 'flex', gap: 8 }}>
                                    <button className="btn btn-primary btn-sm" onClick={handleSave} disabled={saving}>
                                        {saving ? 'Saving...' : 'Save Changes'}
                                    </button>
                                    <button className="btn btn-ghost btn-sm" onClick={() => setEditing(false)}>Cancel</button>
                                </div>
                            </div>
                        ) : (
                            <>
                                <h2 style={{ fontSize: 22, fontWeight: 700 }}>{profile?.full_name || 'Developer'}</h2>
                                <p style={{ color: 'var(--text-secondary)', fontSize: 14 }}>{user?.email}</p>
                                <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
                                    <span className="badge badge-primary">{profile?.skill_level || 'beginner'}</span>
                                    <span className="badge badge-cyan">{profile?.preferred_language || 'javascript'}</span>
                                    {profile?.username && <span className="badge badge-green">@{profile.username}</span>}
                                </div>
                                <button className="btn btn-secondary btn-sm" style={{ marginTop: 12 }} onClick={() => setEditing(true)}>
                                    Edit Profile
                                </button>
                            </>
                        )}
                    </div>
                </div>
            </div>

            {/* Stats */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 24 }}>
                <div className="glass-card" style={{ textAlign: 'center' }}>
                    <div className="stat-value">{totalStats.sessions}</div>
                    <div className="stat-label">Total Sessions</div>
                </div>
                <div className="glass-card" style={{ textAlign: 'center' }}>
                    <div className="stat-value">{totalStats.errors}</div>
                    <div className="stat-label">Errors Resolved</div>
                </div>
                <div className="glass-card" style={{ textAlign: 'center' }}>
                    <div className="stat-value">{skillProfiles.length}</div>
                    <div className="stat-label">Languages Used</div>
                </div>
            </div>

            {/* Skill Profiles */}
            <div className="glass-card">
                <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 16 }}>Skill Profiles by Language</h3>
                {skillProfiles.length === 0 ? (
                    <p style={{ color: 'var(--text-muted)', fontSize: 14 }}>
                        No skill data yet. Start coding to build your skill profile!
                    </p>
                ) : (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                        {skillProfiles.map(skill => (
                            <div key={skill.id} style={{
                                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                                padding: '12px 16px', background: 'var(--bg-tertiary)', borderRadius: 'var(--radius-sm)'
                            }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                                    <span className="badge badge-primary">{skill.language}</span>
                                    <span style={{ fontSize: 14 }}>{skill.total_sessions} sessions</span>
                                </div>
                                <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                                    <span style={{ fontSize: 13, color: 'var(--text-secondary)' }}>{skill.errors_resolved} errors fixed</span>
                                    <div style={{ width: 80, height: 6, background: 'var(--bg-secondary)', borderRadius: 3, overflow: 'hidden' }}>
                                        <div style={{
                                            width: `${Math.min(100, Number(skill.confidence_score))}%`,
                                            height: '100%',
                                            background: 'var(--gradient-primary)',
                                            borderRadius: 3,
                                            transition: 'width 0.5s ease',
                                        }} />
                                    </div>
                                    <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--accent-primary)', minWidth: 35, textAlign: 'right' }}>
                                        {Number(skill.confidence_score).toFixed(0)}%
                                    </span>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    )
}
