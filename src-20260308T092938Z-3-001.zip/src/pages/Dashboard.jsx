import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../hooks/useAuth'
import { supabase } from '../lib/supabase'

function ConfidenceRing({ score }) {
    const radius = 50
    const circumference = 2 * Math.PI * radius
    const offset = circumference - (score / 100) * circumference

    return (
        <div className="confidence-ring">
            <svg width="120" height="120" viewBox="0 0 120 120">
                <defs>
                    <linearGradient id="confidence-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#6366f1" />
                        <stop offset="100%" stopColor="#a78bfa" />
                    </linearGradient>
                </defs>
                <circle className="bg-ring" cx="60" cy="60" r={radius} />
                <circle
                    className="fg-ring"
                    cx="60" cy="60" r={radius}
                    strokeDasharray={circumference}
                    strokeDashoffset={offset}
                />
            </svg>
            <div className="confidence-value">
                {Math.round(score)}
                <span className="confidence-label">CONFIDENCE</span>
            </div>
        </div>
    )
}

export default function Dashboard() {
    const { user, profile } = useAuth()
    const [stats, setStats] = useState({ sessions: 0, errors: 0, confidence: 0 })
    const [recentSessions, setRecentSessions] = useState([])
    const [patterns, setPatterns] = useState([])
    const [loading, setLoading] = useState(true)

    useEffect(() => {
        if (user) loadDashboardData()
    }, [user])

    async function loadDashboardData() {
        const [sessionsRes, patternsRes, skillsRes] = await Promise.all([
            supabase.from('coding_sessions').select('*').eq('user_id', user.id).order('created_at', { ascending: false }).limit(5),
            supabase.from('learning_patterns').select('*').eq('user_id', user.id).order('occurrence_count', { ascending: false }).limit(5),
            supabase.from('skill_profiles').select('*').eq('user_id', user.id),
        ])

        setRecentSessions(sessionsRes.data || [])
        setPatterns(patternsRes.data || [])

        const skills = skillsRes.data || []
        const totalSessions = skills.reduce((acc, s) => acc + s.total_sessions, 0)
        const totalErrors = skills.reduce((acc, s) => acc + s.errors_resolved, 0)
        const avgConfidence = skills.length > 0
            ? skills.reduce((acc, s) => acc + Number(s.confidence_score), 0) / skills.length
            : 0

        setStats({ sessions: totalSessions, errors: totalErrors, confidence: avgConfidence })
        setLoading(false)
    }

    const greeting = () => {
        const hour = new Date().getHours()
        if (hour < 12) return 'Good morning'
        if (hour < 17) return 'Good afternoon'
        return 'Good evening'
    }

    if (loading) {
        return (
            <div className="page-container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '60vh' }}>
                <div className="spinner" style={{ width: 40, height: 40 }} />
            </div>
        )
    }

    return (
        <div className="page-container">
            <div className="page-header">
                <h1 className="page-title">{greeting()}, {profile?.full_name || 'Developer'} 👋</h1>
                <p className="page-subtitle">Here's your learning overview</p>
            </div>

            {/* Stats Row */}
            <div className="widget-grid">
                <div className="glass-card stat-card">
                    <div className="stat-icon purple">📝</div>
                    <div>
                        <div className="stat-value">{stats.sessions}</div>
                        <div className="stat-label">Total Sessions</div>
                    </div>
                </div>
                <div className="glass-card stat-card">
                    <div className="stat-icon green">✅</div>
                    <div>
                        <div className="stat-value">{stats.errors}</div>
                        <div className="stat-label">Errors Resolved</div>
                    </div>
                </div>
                <div className="glass-card stat-card">
                    <div className="stat-icon amber">🎯</div>
                    <div>
                        <div className="stat-value">{stats.confidence.toFixed(0)}%</div>
                        <div className="stat-label">Confidence Score</div>
                    </div>
                </div>
            </div>

            {/* Main Content Grid */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: 24 }}>
                {/* Left Column */}
                <div>
                    {/* Quick Action */}
                    <div className="glass-card" style={{ marginBottom: 24, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                        <div>
                            <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 4 }}>Ready to code?</h3>
                            <p style={{ color: 'var(--text-secondary)', fontSize: 14 }}>Start a new coding session with AI mentoring</p>
                        </div>
                        <Link to="/editor" className="btn btn-primary">
                            Open Editor →
                        </Link>
                    </div>

                    {/* Learning Patterns */}
                    <div className="glass-card" style={{ marginBottom: 24 }}>
                        <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 16 }}>🧠 Learning Pattern Insights</h3>
                        {patterns.length === 0 ? (
                            <p style={{ color: 'var(--text-muted)', fontSize: 14 }}>
                                No patterns yet. Start coding to see AI-generated insights!
                            </p>
                        ) : (
                            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                                {patterns.map((p, i) => (
                                    <div key={i} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 0' }}>
                                        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                                            <span className="badge badge-amber">{p.error_category}</span>
                                        </div>
                                        <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>
                                            {p.occurrence_count}x encountered
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>

                    {/* Recent Sessions */}
                    <div className="glass-card">
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
                            <h3 style={{ fontSize: 16, fontWeight: 700 }}>Recent Sessions</h3>
                            <Link to="/history" style={{ fontSize: 13, color: 'var(--accent-primary)' }}>View All →</Link>
                        </div>
                        {recentSessions.length === 0 ? (
                            <p style={{ color: 'var(--text-muted)', fontSize: 14 }}>
                                No sessions yet. Go to the <Link to="/editor">Code Editor</Link> to start!
                            </p>
                        ) : (
                            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                                {recentSessions.map((s) => (
                                    <div key={s.id} style={{
                                        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                                        padding: '10px 14px', background: 'var(--bg-tertiary)', borderRadius: 'var(--radius-sm)',
                                    }}>
                                        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                                            <span className={`badge ${s.error_type ? 'badge-red' : 'badge-green'}`}>
                                                {s.language}
                                            </span>
                                            <span style={{ fontSize: 13 }}>
                                                {s.error_type || 'Clean code'}
                                            </span>
                                        </div>
                                        <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                                            {new Date(s.created_at).toLocaleDateString()}
                                        </span>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                </div>

                {/* Right Column */}
                <div>
                    {/* Confidence Ring */}
                    <div className="glass-card" style={{ textAlign: 'center', marginBottom: 24 }}>
                        <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 20 }}>Confidence Score</h3>
                        <div style={{ display: 'flex', justifyContent: 'center' }}>
                            <ConfidenceRing score={stats.confidence} />
                        </div>
                        <p style={{ marginTop: 16, fontSize: 13, color: 'var(--text-secondary)' }}>
                            Based on error frequency, fix speed, and improvement trend
                        </p>
                    </div>

                    {/* Recommendations */}
                    <div className="glass-card">
                        <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 16 }}>💡 Personalized Recommendations</h3>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                            {(patterns.length > 0 ? [
                                `Practice fixing ${patterns[0]?.error_category} errors`,
                                'Review your most common mistakes',
                                'Try a mini-project to build confidence',
                            ] : [
                                'Start with a simple JavaScript snippet',
                                'Try the AI Mentor Chat for concept help',
                                'Write some Python to explore analysis',
                            ]).map((rec, i) => (
                                <div key={i} style={{
                                    display: 'flex', alignItems: 'center', gap: 10,
                                    padding: '8px 12px', background: 'var(--bg-tertiary)', borderRadius: 'var(--radius-sm)',
                                    fontSize: 13
                                }}>
                                    <span style={{ color: 'var(--accent-primary)' }}>→</span>
                                    {rec}
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
