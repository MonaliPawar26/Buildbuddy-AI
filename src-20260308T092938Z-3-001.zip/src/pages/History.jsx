import { useState, useEffect } from 'react'
import { useAuth } from '../hooks/useAuth'
import { supabase } from '../lib/supabase'

export default function History() {
    const { user } = useAuth()
    const [sessions, setSessions] = useState([])
    const [loading, setLoading] = useState(true)
    const [filter, setFilter] = useState('all')
    const [expandedId, setExpandedId] = useState(null)

    useEffect(() => {
        if (user) loadSessions()
    }, [user])

    async function loadSessions() {
        const { data } = await supabase
            .from('coding_sessions')
            .select('*')
            .eq('user_id', user.id)
            .order('created_at', { ascending: false })
        setSessions(data || [])
        setLoading(false)
    }

    const filtered = filter === 'all'
        ? sessions
        : sessions.filter(s => s.language === filter)

    const languages = [...new Set(sessions.map(s => s.language))]

    if (loading) {
        return (
            <div className="page-container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '60vh' }}>
                <div className="spinner" style={{ width: 40, height: 40 }} />
            </div>
        )
    }

    return (
        <div className="page-container">
            <div className="page-header">
                <h1 className="page-title">Learning Timeline 📚</h1>
                <p className="page-subtitle">Your coding sessions and progress over time</p>
            </div>

            {/* Filters */}
            <div style={{ display: 'flex', gap: 8, marginBottom: 32 }}>
                <button
                    className={`btn ${filter === 'all' ? 'btn-primary' : 'btn-secondary'} btn-sm`}
                    onClick={() => setFilter('all')}
                >
                    All ({sessions.length})
                </button>
                {languages.map(lang => (
                    <button
                        key={lang}
                        className={`btn ${filter === lang ? 'btn-primary' : 'btn-secondary'} btn-sm`}
                        onClick={() => setFilter(lang)}
                    >
                        {lang}
                    </button>
                ))}
            </div>

            {/* Timeline */}
            {filtered.length === 0 ? (
                <div className="glass-card" style={{ textAlign: 'center', padding: 60 }}>
                    <div style={{ fontSize: 48, marginBottom: 16, opacity: 0.5 }}>📝</div>
                    <h3 style={{ fontSize: 18, fontWeight: 700, marginBottom: 8 }}>No sessions yet</h3>
                    <p style={{ color: 'var(--text-secondary)', fontSize: 14 }}>
                        Your coding sessions will appear here as a learning timeline.
                    </p>
                </div>
            ) : (
                <div className="timeline">
                    {filtered.map((session) => {
                        const isExpanded = expandedId === session.id
                        const response = session.ai_response

                        return (
                            <div key={session.id} className="timeline-item" onClick={() => setExpandedId(isExpanded ? null : session.id)}>
                                <div className="timeline-dot" />
                                <div className="glass-card" style={{ padding: 16 }}>
                                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: isExpanded ? 16 : 0 }}>
                                        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                                            <span className={`badge ${session.error_type ? 'badge-red' : 'badge-green'}`}>
                                                {session.error_type || 'Clean'}
                                            </span>
                                            <span className="badge badge-primary">{session.language}</span>
                                        </div>
                                        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                                            <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                                                {new Date(session.created_at).toLocaleDateString()} · {new Date(session.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                            </span>
                                            <span style={{ color: 'var(--text-muted)', fontSize: 12 }}>{isExpanded ? '▲' : '▼'}</span>
                                        </div>
                                    </div>

                                    {isExpanded && (
                                        <div style={{ animation: 'fadeInUp 0.3s ease' }}>
                                            <div style={{ marginBottom: 16 }}>
                                                <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-secondary)', marginBottom: 8 }}>YOUR CODE</div>
                                                <pre style={{
                                                    background: 'var(--bg-secondary)', border: '1px solid var(--border-color)',
                                                    padding: 16, borderRadius: 'var(--radius-sm)', fontFamily: 'var(--font-mono)',
                                                    fontSize: 13, overflow: 'auto', maxHeight: 200
                                                }}>
                                                    {session.code}
                                                </pre>
                                            </div>
                                            {response && (
                                                <div>
                                                    <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-secondary)', marginBottom: 8 }}>AI ANALYSIS</div>
                                                    <p style={{ fontSize: 14, lineHeight: 1.7 }}>{response.explanation}</p>
                                                    {response.concept && (
                                                        <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 8, fontStyle: 'italic' }}>
                                                            💡 {response.concept}
                                                        </p>
                                                    )}
                                                </div>
                                            )}
                                        </div>
                                    )}
                                </div>
                            </div>
                        )
                    })}
                </div>
            )}
        </div>
    )
}
