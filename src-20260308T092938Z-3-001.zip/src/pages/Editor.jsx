import { useState, useRef } from 'react'
import Editor from '@monaco-editor/react'
import { useAuth } from '../hooks/useAuth'
import { supabase } from '../lib/supabase'

const analyzeSteps = [
    'Parsing your code...',
    'Checking memory for patterns...',
    'Generating explanation...',
    'Structuring fix...',
]

export default function EditorPage() {
    const { user } = useAuth()
    const [code, setCode] = useState(`// Welcome to BuildBuddy AI! 🚀
// Write your code here and click "Analyze" to get AI mentoring.

function greetUser(name) {
  if (name == "World") {
    var message = "Hello, " + name + "!"
    console.log(message)
  }
  return message
}

greetUser("World")
`)
    const [language, setLanguage] = useState('javascript')
    const [result, setResult] = useState(null)
    const [analyzing, setAnalyzing] = useState(false)
    const [activeStep, setActiveStep] = useState(-1)
    const editorRef = useRef(null)

    function handleEditorMount(editor) {
        editorRef.current = editor
    }

    async function handleAnalyze() {
        setAnalyzing(true)
        setResult(null)

        // Animate steps
        for (let i = 0; i < analyzeSteps.length; i++) {
            setActiveStep(i)
            await new Promise(r => setTimeout(r, 600))
        }

        try {
            const { data: { session } } = await supabase.auth.getSession()
            const { data, error } = await supabase.functions.invoke('analyze-code', {
                body: { language, code },
                headers: {
                    Authorization: `Bearer ${session?.access_token}`
                }
            })

            if (error) throw error
            setResult(data)
        } catch (err) {
            console.error('Analysis error:', err)
            setResult({
                error_type: 'Analysis Failed',
                has_error: true,
                explanation: err.message || 'The AI mentor encountered an unexpected error. Please try again.',
                step_by_step_fix: ['Check your internet connection', 'Try refreshing the page', 'Contact support if the issue persists'],
                corrected_code: code,
                concept: '',
                confidence_tip: '',
                context_used: { similar_past_mistakes: [], explanation_depth: 'standard', related_sessions: 0 },
            })
        }

        setAnalyzing(false)
        setActiveStep(-1)
    }

    return (
        <div className="editor-layout">
            {/* Left: Code Editor */}
            <div className="editor-panel">
                <div className="editor-toolbar">
                    <div className="editor-toolbar-left">
                        <select
                            id="language-select"
                            className="input-field"
                            style={{ width: 150, padding: '6px 12px' }}
                            value={language}
                            onChange={(e) => setLanguage(e.target.value)}
                        >
                            <option value="javascript">JavaScript</option>
                            <option value="python">Python</option>
                            <option value="typescript">TypeScript</option>
                            <option value="java">Java</option>
                            <option value="cpp">C++</option>
                            <option value="csharp">C#</option>
                            <option value="go">Go</option>
                            <option value="rust">Rust</option>
                            <option value="php">PHP</option>
                            <option value="swift">Swift</option>
                            <option value="kotlin">Kotlin</option>
                            <option value="html">HTML</option>
                            <option value="css">CSS</option>
                            <option value="sql">SQL</option>
                        </select>
                        <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>
                            {code.split('\n').length} lines
                        </span>
                    </div>
                    <div className="editor-toolbar-right">
                        <button
                            id="analyze-btn"
                            className="btn btn-primary"
                            onClick={handleAnalyze}
                            disabled={analyzing || !code.trim()}
                        >
                            {analyzing ? (
                                <>
                                    <div className="spinner" style={{ width: 16, height: 16 }} />
                                    Analyzing...
                                </>
                            ) : (
                                '⚡ Analyze'
                            )}
                        </button>
                    </div>
                </div>
                <div className="editor-body">
                    <Editor
                        height="100%"
                        language={language}
                        value={code}
                        onChange={(val) => setCode(val || '')}
                        onMount={handleEditorMount}
                        theme="vs-dark"
                        options={{
                            fontSize: 14,
                            fontFamily: "'JetBrains Mono', monospace",
                            minimap: { enabled: false },
                            padding: { top: 16 },
                            scrollBeyondLastLine: false,
                            lineNumbers: 'on',
                            renderLineHighlight: 'all',
                            bracketPairColorization: { enabled: true },
                            smoothScrolling: true,
                            cursorBlinking: 'smooth',
                            cursorSmoothCaretAnimation: 'on',
                        }}
                    />
                </div>
            </div>

            {/* Right: AI Panel */}
            <div className="ai-panel">
                <div className="ai-panel-header">
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span style={{ fontSize: 18 }}>🤖</span>
                        <span style={{ fontWeight: 700, fontSize: 14 }}>AI Mentor</span>
                    </div>
                    {result && (
                        <span className={`badge ${result.has_error ? 'badge-red' : 'badge-green'}`}>
                            {result.has_error ? result.error_type : 'All Good!'}
                        </span>
                    )}
                </div>

                <div className="ai-panel-body">
                    {/* Empty State */}
                    {!analyzing && !result && (
                        <div className="ai-panel-empty">
                            <div className="ai-panel-empty-icon">🧠</div>
                            <div>
                                <h3 style={{ fontSize: 18, fontWeight: 700, marginBottom: 8, color: 'var(--text-primary)' }}>
                                    Ready to Analyze
                                </h3>
                                <p style={{ fontSize: 14 }}>
                                    Write some code and click <strong>⚡ Analyze</strong> to get<br />
                                    AI-powered mentoring with step-by-step explanations.
                                </p>
                            </div>
                        </div>
                    )}

                    {/* Analyzing Animation */}
                    {analyzing && (
                        <div className="analyzing-overlay">
                            <div className="spinner" style={{ width: 40, height: 40 }} />
                            <div className="analyzing-steps">
                                {analyzeSteps.map((step, i) => (
                                    <div key={i} className={`analyzing-step ${i < activeStep ? 'done' : i === activeStep ? 'active' : ''}`}>
                                        <div className="analyzing-step-dot" />
                                        <span>{step}</span>
                                        {i < activeStep && <span style={{ marginLeft: 'auto' }}>✓</span>}
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {/* Results */}
                    {result && !analyzing && (
                        <div className="ai-result">
                            {/* Error Explanation */}
                            <div className="ai-section">
                                <div className="ai-section-title">
                                    {result.has_error ? '❌' : '✅'} {result.has_error ? 'Issue Detected' : 'Analysis Result'}
                                </div>
                                <div className="ai-section-content">
                                    {result.explanation}
                                </div>
                            </div>

                            {/* Step-by-Step Fix */}
                            {result.step_by_step_fix?.length > 0 && (
                                <div className="ai-section">
                                    <div className="ai-section-title">🔧 Step-by-Step Fix</div>
                                    <div className="ai-section-content">
                                        {result.step_by_step_fix.map((step, i) => (
                                            <div key={i} className="fix-step">
                                                <div className="fix-step-number">{i + 1}</div>
                                                <span>{step}</span>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}

                            {/* Corrected Code */}
                            {result.has_error && result.corrected_code !== code && (
                                <div className="ai-section">
                                    <div className="ai-section-title">💻 Corrected Code</div>
                                    <div className="ai-section-content">
                                        <pre><code>{result.corrected_code}</code></pre>
                                        <button
                                            className="btn btn-secondary btn-sm"
                                            onClick={() => setCode(result.corrected_code)}
                                            style={{ marginTop: 8 }}
                                        >
                                            Apply Fix →
                                        </button>
                                    </div>
                                </div>
                            )}

                            {/* Concept */}
                            {result.concept && (
                                <div className="ai-section">
                                    <div className="ai-section-title">📚 Concept Explanation</div>
                                    <div className="ai-section-content">{result.concept}</div>
                                </div>
                            )}

                            {/* Confidence Tip */}
                            {result.confidence_tip && (
                                <div className="ai-section" style={{ borderColor: 'rgba(99, 102, 241, 0.3)', background: 'rgba(99, 102, 241, 0.05)' }}>
                                    <div className="ai-section-title">💪 Confidence Tip</div>
                                    <div className="ai-section-content">{result.confidence_tip}</div>
                                </div>
                            )}

                            {/* Context Transparency */}
                            {result.context_used && (
                                <details className="ai-section" style={{ cursor: 'pointer' }}>
                                    <summary className="ai-section-title" style={{ marginBottom: 0 }}>
                                        🔍 Context Used in This Explanation
                                    </summary>
                                    <div className="ai-section-content" style={{ marginTop: 12 }}>
                                        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                                            <div style={{ fontSize: 13 }}>
                                                <strong>Explanation depth:</strong> {result.context_used.explanation_depth}
                                            </div>
                                            <div style={{ fontSize: 13 }}>
                                                <strong>Related sessions:</strong> {result.context_used.related_sessions}
                                            </div>
                                            {result.context_used.similar_past_mistakes?.length > 0 && (
                                                <div style={{ fontSize: 13 }}>
                                                    <strong>Similar past mistakes:</strong>{' '}
                                                    {result.context_used.similar_past_mistakes.map((m, i) => (
                                                        <span key={i} className="badge badge-amber" style={{ marginLeft: 4 }}>{m}</span>
                                                    ))}
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                </details>
                            )}
                        </div>
                    )}
                </div>
            </div>
        </div>
    )
}
