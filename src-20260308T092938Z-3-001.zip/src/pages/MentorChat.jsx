import { useState, useRef, useEffect } from 'react'
import ReactMarkdown from 'react-markdown'
import { useAuth } from '../hooks/useAuth'
import { supabase } from '../lib/supabase'

export default function MentorChat() {
    const { user, profile } = useAuth()
    const [messages, setMessages] = useState([
        {
            role: 'assistant',
            content: `Hey there! 👋 I'm your **BuildBuddy AI Mentor**.\n\nI'm here to help you learn coding concepts, debug issues, and build confidence. Try asking me about:\n\n- **Recursion** — How recursive functions work\n- **Async/Await** — Mastering asynchronous JavaScript\n- **Closures** — Understanding scope and closures\n- **Scope** — Variable accessibility rules\n\nOr just ask me anything! 🚀`,
        },
    ])
    const [input, setInput] = useState('')
    const [sending, setSending] = useState(false)
    const [context, setContext] = useState({ skill_level: 'beginner', recent_sessions_count: 0, preferred_language: 'javascript' })
    const messagesEndRef = useRef(null)

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
    }, [messages])

    async function handleSend() {
        if (!input.trim() || sending) return
        const msg = input.trim()
        setInput('')
        setMessages(prev => [...prev, { role: 'user', content: msg }])
        setSending(true)

        try {
            const { data: { session } } = await supabase.auth.getSession()
            const { data, error } = await supabase.functions.invoke('ai-mentor-chat', {
                body: { message: msg, session_context: { language: context.preferred_language } },
                headers: {
                    Authorization: `Bearer ${session?.access_token}`
                }
            })

            if (error) throw error
            setMessages(prev => [...prev, { role: 'assistant', content: data.response || 'I processed your request but had trouble forming a specific response. Let me try again!' }])
            if (data.context) setContext(data.context)
        } catch (err) {
            console.error('Chat error:', err)
            setMessages(prev => [...prev, { role: 'ai', content: 'Sorry, I had trouble connecting. Please try again! 🔄' }])
        }

        setSending(false)
    }

    function handleKeyDown(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault()
            handleSend()
        }
    }

    return (
        <div className="chat-container">
            {/* Context Banner */}
            <div className="chat-context-banner">
                <span style={{ fontWeight: 600, color: 'var(--accent-primary)' }}>🧠 Using context from:</span>{' '}
                Last {context.recent_sessions_count} coding sessions · Skill Level: {context.skill_level} · Language: {context.preferred_language}
            </div>

            {/* Messages */}
            <div className="chat-messages">
                {messages.map((msg, i) => (
                    <div key={i} className={`chat-message ${msg.role === 'user' ? 'user' : 'ai'}`}>
                        {(msg.role === 'ai' || msg.role === 'assistant') ? (
                            <div className="markdown-content">
                                <ReactMarkdown>
                                    {msg.content}
                                </ReactMarkdown>
                            </div>
                        ) : (
                            msg.content
                        )}
                    </div>
                ))}
                {sending && (
                    <div className="chat-message ai" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <div className="spinner" style={{ width: 16, height: 16 }} />
                        <span style={{ color: 'var(--text-muted)' }}>Thinking...</span>
                    </div>
                )}
                <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="chat-input-area">
                <textarea
                    id="chat-input"
                    className="chat-input"
                    placeholder="Ask me anything about coding..."
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                    rows={1}
                />
                <button
                    id="chat-send"
                    className="btn btn-primary"
                    onClick={handleSend}
                    disabled={!input.trim() || sending}
                >
                    Send
                </button>
            </div>
        </div>
    )
}
