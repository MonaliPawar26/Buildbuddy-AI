import { Link } from 'react-router-dom'

const features = [
    { icon: '🔍', title: 'Smart Code Analysis', desc: 'AI analyzes your code in real-time, identifying bugs, anti-patterns, and areas for improvement.', color: 'rgba(99, 102, 241, 0.15)' },
    { icon: '🧠', title: 'Persistent Memory', desc: 'Remembers your mistakes and tracks improvement over time. Your personal coding journal, powered by AI.', color: 'rgba(139, 92, 246, 0.15)' },
    { icon: '📚', title: 'Step-by-Step Fixes', desc: 'Not just what\'s wrong — understand WHY errors occur and HOW to fix them with structured explanations.', color: 'rgba(52, 211, 153, 0.15)' },
    { icon: '🎯', title: 'Adaptive Learning', desc: 'Explanations adapt to your skill level. Beginner-friendly today, advanced tomorrow as you grow.', color: 'rgba(34, 211, 238, 0.15)' },
    { icon: '📈', title: 'Confidence Score', desc: 'Track your progress with a dynamic confidence score calculated from your error reduction and fix speed.', color: 'rgba(251, 191, 36, 0.15)' },
    { icon: '💬', title: 'AI Mentor Chat', desc: 'Ask questions anytime. Your mentor uses your coding history to give personalized, contextual answers.', color: 'rgba(248, 113, 113, 0.15)' },
]

const mcpFeatures = [
    '🧠 Learns from your mistakes',
    '📊 Tracks improvement over time',
    '🎓 Adapts explanations to your level',
    '📁 Remembers your projects',
]

export default function Landing() {
    return (
        <div>
            {/* Navbar */}
            <nav className="navbar" style={{ position: 'fixed', width: '100%', zIndex: 100 }}>
                <div className="navbar-brand">
                    <span style={{ fontSize: 24 }}>⚡</span>
                    <span>BuildBuddy AI</span>
                </div>
                <div className="navbar-links">
                    <Link to="/login" className="btn btn-ghost">Log In</Link>
                    <Link to="/register" className="btn btn-primary">Get Started Free</Link>
                </div>
            </nav>

            {/* Hero */}
            <section className="landing-hero">
                <div className="hero-badge">
                    ✨ Powered by Persistent AI Context (MCP)
                </div>
                <h1 className="hero-title">
                    AI that doesn't just answer —<br />
                    it <span className="gradient-text">teaches.</span>
                </h1>
                <p className="hero-subtitle">
                    Your real-time AI coding mentor that analyzes your code, explains errors,
                    gives step-by-step fixes, and remembers your learning journey.
                </p>
                <div className="hero-actions">
                    <Link to="/register" className="btn btn-primary btn-lg">
                        Start Learning Free →
                    </Link>
                    <Link to="/login" className="btn btn-secondary btn-lg">
                        Sign In
                    </Link>
                </div>
            </section>

            {/* Features */}
            <section className="features-section">
                <h2 className="features-title">Everything you need to level up</h2>
                <p className="features-subtitle">More than an assistant — a mentor that grows with you</p>
                <div className="features-grid">
                    {features.map((f, i) => (
                        <div key={i} className="glass-card feature-card" style={{ animationDelay: `${i * 100}ms` }}>
                            <div className="feature-icon" style={{ background: f.color }}>
                                {f.icon}
                            </div>
                            <h3 className="feature-title">{f.title}</h3>
                            <p className="feature-desc">{f.desc}</p>
                        </div>
                    ))}
                </div>
            </section>

            {/* MCP Banner */}
            <section className="mcp-banner">
                <div className="hero-badge" style={{ marginBottom: 16 }}>🔗 MCP Technology</div>
                <h2 style={{ fontSize: 32, fontWeight: 800, marginBottom: 8 }}>
                    Powered by <span className="gradient-text" style={{ background: 'var(--gradient-primary)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Persistent AI Context</span>
                </h2>
                <p style={{ color: 'var(--text-secondary)', maxWidth: 500, margin: '0 auto' }}>
                    Unlike generic AI assistants, BuildBuddy uses Model Context Protocol to maintain a persistent memory of your learning journey.
                </p>
                <div className="mcp-pills">
                    {mcpFeatures.map((f, i) => (
                        <div key={i} className="mcp-pill">{f}</div>
                    ))}
                </div>
            </section>

            {/* CTA */}
            <section style={{ padding: '80px 32px', textAlign: 'center' }}>
                <h2 style={{ fontSize: 36, fontWeight: 800, marginBottom: 16 }}>
                    Ready to code <span className="gradient-text" style={{ background: 'var(--gradient-primary)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>smarter</span>?
                </h2>
                <p style={{ color: 'var(--text-secondary)', marginBottom: 32, fontSize: 16 }}>
                    Join thousands of developers who learn faster with AI mentoring.
                </p>
                <Link to="/register" className="btn btn-primary btn-lg">
                    Create Free Account →
                </Link>
            </section>

            {/* Footer */}
            <footer style={{ padding: '32px', borderTop: '1px solid var(--border-color)', textAlign: 'center', color: 'var(--text-muted)', fontSize: 13 }}>
                © 2026 BuildBuddy AI. Built with ❤️ for developers.
            </footer>
        </div>
    )
}
